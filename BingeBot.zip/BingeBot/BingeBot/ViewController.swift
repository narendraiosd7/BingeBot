//
//  ViewController.swift
//  BingeBot
//
//  Created by Vadde Narendra on 5/1/20.
//  Copyright © 2020 Narendra Vadde. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var showsLabel: UILabel!
    @IBOutlet weak var suggestedShowLabel: UILabel!
    @IBOutlet weak var bingeBotSpokenLebel: UILabel!
    @IBOutlet weak var enterShowsTextField: UITextField!
    @IBOutlet weak var showLabelStackView: UIStackView!
    @IBOutlet weak var suggestedShowsStackView: UIStackView!
    @IBOutlet weak var addShowStackView: UIStackView!
    
    var shows: [String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        showLabelStackView.isHidden = true
        suggestedShowsStackView.isHidden = true
    }
    
    func updateShowLabel() {
        showsLabel.text = shows.joined(separator: ", ")
    }
    
    @IBAction func whatToBingeButtonTapped(_ sender: UIButton) {
        suggestedShowLabel.text = shows.randomElement()
        bingeBotSpokenLebel.isHidden = false
        suggestedShowLabel.isHidden = false
    }
    
    @IBAction func addShowButtonTapped(_ sender: UIButton) {
        guard let showName = enterShowsTextField.text else {return}
        shows.append(showName)
        updateShowLabel()
        enterShowsTextField.text = ""
        showLabelStackView.isHidden = false
        if (shows.count > 1) {
            suggestedShowsStackView.isHidden = false
            bingeBotSpokenLebel.isHidden = true
            suggestedShowLabel.isHidden = true
        }
    }
    

}

